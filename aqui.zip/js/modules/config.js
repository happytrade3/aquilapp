/**
 * Módulo Config (anteriormente ConfigUI)
 * Responsável pelas configurações do usuário
 */

// Esta classe será preenchida com o conteúdo da antiga ConfigUI
class Config {
    // Conteúdo será extraído do código original
}

// Exposição global para compatibilidade
window.Config = Config;
