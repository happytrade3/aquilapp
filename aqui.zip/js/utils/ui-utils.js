/**
 * Utilitários de UI
 * Funções comuns usadas por múltiplos módulos
 */

const UIUtils = {
    // Funções utilitárias serão extraídas aqui
};

// Exposição global para compatibilidade
window.UIUtils = UIUtils;
